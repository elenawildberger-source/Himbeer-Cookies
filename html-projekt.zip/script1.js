// script.js

document.getElementById("toggleDark").addEventListener("click", function(){
  document.body.classList.toggle("dark");
});